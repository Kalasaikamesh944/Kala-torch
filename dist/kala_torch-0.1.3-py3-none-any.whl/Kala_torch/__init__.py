from .Kala_torch import  Kala_torch

__all__ = ['Kala_torch']

__version__ = '0.1.3'
__author__ = ('N V R K SAI KAMESH YADAVALLi')
__email__ = 'saikamesh.y@gmail.com'
__license__ = 'MIT'
